package a_package;

public class test1 {	
	public int sum(int a,int b) {
		return a + b;
	}

}
